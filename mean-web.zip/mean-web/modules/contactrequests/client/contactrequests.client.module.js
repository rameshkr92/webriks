(function (app) {
  'use strict';

  app.registerModule('contactrequests', ['core','smart-table','ui.tinymce']);// The core module is required for special route handling; see /core/client/config/core.client.routes
  app.registerModule('contactrequests.admin', ['core.admin','smart-table','ui.tinymce']);
  app.registerModule('contactrequests.admin.routes', ['core.admin.routes']);
  app.registerModule('contactrequests.services');
  app.registerModule('contactrequests.routes', ['ui.router', 'core.routes', 'contactrequests.services']);
}(ApplicationConfiguration));
