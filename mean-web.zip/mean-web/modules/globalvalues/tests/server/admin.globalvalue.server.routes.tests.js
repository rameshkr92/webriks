﻿'use strict';

var should = require('should'),
  request = require('supertest'),
  path = require('path'),
  mongoose = require('mongoose'),
  User = mongoose.model('User'),
  Globalvalue = mongoose.model('Globalvalue'),
  express = require(path.resolve('./config/lib/express'));

/**
 * Globals
 */
var app,
  agent,
  credentials,
  user,
  globalvalue;

/**
 * Globalvalue routes tests
 */
describe('Globalvalue Admin CRUD tests', function () {
  before(function (done) {
    // Get application
    app = express.init(mongoose);
    agent = request.agent(app);

    done();
  });

  beforeEach(function (done) {
    // Create user credentials
    credentials = {
      usernameOrEmail: 'username',
      password: 'M3@n.jsI$Aw3$0m3'
    };

    // Create a new user
    user = new User({
      firstName: 'Full',
      lastName: 'Name',
      displayName: 'Full Name',
      email: 'test@test.com',
      roles: ['user', 'admin'],
      username: credentials.usernameOrEmail,
      password: credentials.password,
      provider: 'local'
    });

    // Save a user to the test db and create new globalvalue
    user.save(function () {
      globalvalue = {
        title: 'Globalvalue Title',
        content: 'Globalvalue Content'
      };

      done();
    });
  });

  it('should be able to save an globalvalue if logged in', function (done) {
    agent.post('/api/auth/signin')
      .send(credentials)
      .expect(200)
      .end(function (signinErr, signinRes) {
        // Handle signin error
        if (signinErr) {
          return done(signinErr);
        }

        // Get the userId
        var userId = user.id;

        // Save a new globalvalue
        agent.post('/api/globalvalues')
          .send(globalvalue)
          .expect(200)
          .end(function (globalvalueSaveErr, globalvalueSaveRes) {
            // Handle globalvalue save error
            if (globalvalueSaveErr) {
              return done(globalvalueSaveErr);
            }

            // Get a list of globalvalues
            agent.get('/api/globalvalues')
              .end(function (globalvaluesGetErr, globalvaluesGetRes) {
                // Handle globalvalue save error
                if (globalvaluesGetErr) {
                  return done(globalvaluesGetErr);
                }

                // Get globalvalues list
                var globalvalues = globalvaluesGetRes.body;

                // Set assertions
                (globalvalues[0].user._id).should.equal(userId);
                (globalvalues[0].title).should.match('Globalvalue Title');

                // Call the assertion callback
                done();
              });
          });
      });
  });

  it('should be able to update an globalvalue if signed in', function (done) {
    agent.post('/api/auth/signin')
      .send(credentials)
      .expect(200)
      .end(function (signinErr, signinRes) {
        // Handle signin error
        if (signinErr) {
          return done(signinErr);
        }

        // Get the userId
        var userId = user.id;

        // Save a new globalvalue
        agent.post('/api/globalvalues')
          .send(globalvalue)
          .expect(200)
          .end(function (globalvalueSaveErr, globalvalueSaveRes) {
            // Handle globalvalue save error
            if (globalvalueSaveErr) {
              return done(globalvalueSaveErr);
            }

            // Update globalvalue title
            globalvalue.title = 'WHY YOU GOTTA BE SO MEAN?';

            // Update an existing globalvalue
            agent.put('/api/globalvalues/' + globalvalueSaveRes.body._id)
              .send(globalvalue)
              .expect(200)
              .end(function (globalvalueUpdateErr, globalvalueUpdateRes) {
                // Handle globalvalue update error
                if (globalvalueUpdateErr) {
                  return done(globalvalueUpdateErr);
                }

                // Set assertions
                (globalvalueUpdateRes.body._id).should.equal(globalvalueSaveRes.body._id);
                (globalvalueUpdateRes.body.title).should.match('WHY YOU GOTTA BE SO MEAN?');

                // Call the assertion callback
                done();
              });
          });
      });
  });

  it('should not be able to save an globalvalue if no title is provided', function (done) {
    // Invalidate title field
    globalvalue.title = '';

    agent.post('/api/auth/signin')
      .send(credentials)
      .expect(200)
      .end(function (signinErr, signinRes) {
        // Handle signin error
        if (signinErr) {
          return done(signinErr);
        }

        // Get the userId
        var userId = user.id;

        // Save a new globalvalue
        agent.post('/api/globalvalues')
          .send(globalvalue)
          .expect(422)
          .end(function (globalvalueSaveErr, globalvalueSaveRes) {
            // Set message assertion
            (globalvalueSaveRes.body.message).should.match('Title cannot be blank');

            // Handle globalvalue save error
            done(globalvalueSaveErr);
          });
      });
  });

  it('should be able to delete an globalvalue if signed in', function (done) {
    agent.post('/api/auth/signin')
      .send(credentials)
      .expect(200)
      .end(function (signinErr, signinRes) {
        // Handle signin error
        if (signinErr) {
          return done(signinErr);
        }

        // Get the userId
        var userId = user.id;

        // Save a new globalvalue
        agent.post('/api/globalvalues')
          .send(globalvalue)
          .expect(200)
          .end(function (globalvalueSaveErr, globalvalueSaveRes) {
            // Handle globalvalue save error
            if (globalvalueSaveErr) {
              return done(globalvalueSaveErr);
            }

            // Delete an existing globalvalue
            agent.delete('/api/globalvalues/' + globalvalueSaveRes.body._id)
              .send(globalvalue)
              .expect(200)
              .end(function (globalvalueDeleteErr, globalvalueDeleteRes) {
                // Handle globalvalue error error
                if (globalvalueDeleteErr) {
                  return done(globalvalueDeleteErr);
                }

                // Set assertions
                (globalvalueDeleteRes.body._id).should.equal(globalvalueSaveRes.body._id);

                // Call the assertion callback
                done();
              });
          });
      });
  });

  it('should be able to get a single globalvalue if signed in and verify the custom "isCurrentUserOwner" field is set to "true"', function (done) {
    // Create new globalvalue model instance
    globalvalue.user = user;
    var globalvalueObj = new Globalvalue(globalvalue);

    agent.post('/api/auth/signin')
      .send(credentials)
      .expect(200)
      .end(function (signinErr, signinRes) {
        // Handle signin error
        if (signinErr) {
          return done(signinErr);
        }

        // Get the userId
        var userId = user.id;

        // Save a new globalvalue
        agent.post('/api/globalvalues')
          .send(globalvalue)
          .expect(200)
          .end(function (globalvalueSaveErr, globalvalueSaveRes) {
            // Handle globalvalue save error
            if (globalvalueSaveErr) {
              return done(globalvalueSaveErr);
            }

            // Get the globalvalue
            agent.get('/api/globalvalues/' + globalvalueSaveRes.body._id)
              .expect(200)
              .end(function (globalvalueInfoErr, globalvalueInfoRes) {
                // Handle globalvalue error
                if (globalvalueInfoErr) {
                  return done(globalvalueInfoErr);
                }

                // Set assertions
                (globalvalueInfoRes.body._id).should.equal(globalvalueSaveRes.body._id);
                (globalvalueInfoRes.body.title).should.equal(globalvalue.title);

                // Assert that the "isCurrentUserOwner" field is set to true since the current User created it
                (globalvalueInfoRes.body.isCurrentUserOwner).should.equal(true);

                // Call the assertion callback
                done();
              });
          });
      });
  });

  afterEach(function (done) {
    User.remove().exec(function () {
      Globalvalue.remove().exec(done);
    });
  });
});
