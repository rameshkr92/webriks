'use strict';

describe('Globalvalues E2E Tests:', function () {
  describe('Test globalvalues page', function () {
    it('Should report missing credentials', function () {
      browser.get('http://localhost:3001/globalvalues');
      expect(element.all(by.repeater('globalvalue in globalvalues')).count()).toEqual(0);
    });
  });
});
