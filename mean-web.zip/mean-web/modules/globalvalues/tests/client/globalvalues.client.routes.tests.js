(function () {
  'use strict';

  describe('Globalvalues Route Tests', function () {
    // Initialize global variables
    var $scope,
      GlobalvaluesService;

    // We can start by loading the main application module
    beforeEach(module(ApplicationConfiguration.applicationModuleName));

    // The injector ignores leading and trailing underscores here (i.e. _$httpBackend_).
    // This allows us to inject a service but then attach it to a variable
    // with the same name as the service.
    beforeEach(inject(function ($rootScope, _GlobalvaluesService_) {
      // Set a new global scope
      $scope = $rootScope.$new();
      GlobalvaluesService = _GlobalvaluesService_;
    }));

    describe('Route Config', function () {
      describe('Main Route', function () {
        var mainstate;
        beforeEach(inject(function ($state) {
          mainstate = $state.get('globalvalues');
        }));

        it('Should have the correct URL', function () {
          expect(mainstate.url).toEqual('/globalvalues');
        });

        it('Should be abstract', function () {
          expect(mainstate.abstract).toBe(true);
        });

        it('Should have template', function () {
          expect(mainstate.template).toBe('<ui-view/>');
        });
      });

      describe('List Route', function () {
        var liststate;
        beforeEach(inject(function ($state) {
          liststate = $state.get('globalvalues.list');
        }));

        it('Should have the correct URL', function () {
          expect(liststate.url).toEqual('');
        });

        it('Should not be abstract', function () {
          expect(liststate.abstract).toBe(undefined);
        });

        it('Should have templateUrl', function () {
          expect(liststate.templateUrl).toBe('/modules/globalvalues/client/views/list-globalvalues.client.view.html');
        });
      });

      describe('View Route', function () {
        var viewstate,
          GlobalvaluesController,
          mockGlobalvalue;

        beforeEach(inject(function ($controller, $state, $templateCache) {
          viewstate = $state.get('globalvalues.view');
          $templateCache.put('/modules/globalvalues/client/views/view-globalvalue.client.view.html', '');

          // create mock globalvalue
          mockGlobalvalue = new GlobalvaluesService({
            _id: '525a8422f6d0f87f0e407a33',
            title: 'An Globalvalue about MEAN',
            content: 'MEAN rocks!'
          });

          // Initialize Controller
          GlobalvaluesController = $controller('GlobalvaluesController as vm', {
            $scope: $scope,
            globalvalueResolve: mockGlobalvalue
          });
        }));

        it('Should have the correct URL', function () {
          expect(viewstate.url).toEqual('/:globalvalueId');
        });

        it('Should have a resolve function', function () {
          expect(typeof viewstate.resolve).toEqual('object');
          expect(typeof viewstate.resolve.globalvalueResolve).toEqual('function');
        });

        it('should respond to URL', inject(function ($state) {
          expect($state.href(viewstate, {
            globalvalueId: 1
          })).toEqual('/globalvalues/1');
        }));

        it('should attach an globalvalue to the controller scope', function () {
          expect($scope.vm.globalvalue._id).toBe(mockGlobalvalue._id);
        });

        it('Should not be abstract', function () {
          expect(viewstate.abstract).toBe(undefined);
        });

        it('Should have templateUrl', function () {
          expect(viewstate.templateUrl).toBe('/modules/globalvalues/client/views/view-globalvalue.client.view.html');
        });
      });

      describe('Handle Trailing Slash', function () {
        beforeEach(inject(function ($state, $rootScope, $templateCache) {
          $templateCache.put('/modules/globalvalues/client/views/list-globalvalues.client.view.html', '');

          $state.go('globalvalues.list');
          $rootScope.$digest();
        }));

        it('Should remove trailing slash', inject(function ($state, $location, $rootScope) {
          $location.path('globalvalues/');
          $rootScope.$digest();

          expect($location.path()).toBe('/globalvalues');
          expect($state.current.templateUrl).toBe('/modules/globalvalues/client/views/list-globalvalues.client.view.html');
        }));
      });
    });
  });
}());
