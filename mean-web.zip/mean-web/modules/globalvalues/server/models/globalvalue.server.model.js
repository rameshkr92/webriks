'use strict';

/**
 * Module dependencies
 */
var mongoose = require('mongoose'),
  Schema = mongoose.Schema;

/**
 * Globalvalue Schema
 */
var GlobalvalueSchema = new Schema({
  created: {
    type: Date,
    default: Date.now
  },
  url: {
    type: String,
    default: '',
    required: 'Please fill email template url',
    trim: true
  },
   title:{
        en: {
        type: String,
        default: '',
        required: 'Please fill global value title',
        trim: true
            },
        ar : {
            type: String,
            default: '',
            trim: true
        }
 },
   value:{
        en: {
        type: String,
        default: '',
        required: 'Please fill global value',
        trim: true
            },
        ar : {
            type: String,
            default: '',
            trim: true
        }
 },
  
  user: {
    type: Schema.ObjectId,
    ref: 'User'
  }
});

mongoose.model('Globalvalue', GlobalvalueSchema);
