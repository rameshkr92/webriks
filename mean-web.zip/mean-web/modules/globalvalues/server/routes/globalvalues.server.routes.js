'use strict';

/**
 * Module dependencies
 */
var globalvaluesPolicy = require('../policies/globalvalues.server.policy'),
  globalvalues = require('../controllers/globalvalues.server.controller');

module.exports = function (app) {
  // Globalvalues collection routes
  app.route('/api/globalvalues').all(globalvaluesPolicy.isAllowed)
    .get(globalvalues.list)
    .post(globalvalues.create);

  // Single globalvalue routes
  app.route('/api/globalvalues/:globalvalueId').all(globalvaluesPolicy.isAllowed)
    .get(globalvalues.read)
    .put(globalvalues.update)
    .delete(globalvalues.delete);

  // Finish by binding the globalvalue middleware
  app.param('globalvalueId', globalvalues.globalvalueByID);
};
