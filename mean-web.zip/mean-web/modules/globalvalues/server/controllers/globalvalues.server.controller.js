'use strict';

/**
 * Module dependencies
 */
var path = require('path'),
  mongoose = require('mongoose'),
  Globalvalue = mongoose.model('Globalvalue'),
  errorHandler = require(path.resolve('./modules/core/server/controllers/errors.server.controller'));

/**
 * Create an globalvalue
 */
exports.create = function (req, res) {
  
  var globalvalue = new Globalvalue(req.body);
  globalvalue.user = req.body.user;
    globalvalue.save(function (err) {
    if (err) {
      return res.status(422).send({
        message: errorHandler.getErrorMessage(err)
      });
    } else {
      res.json(globalvalue);
    }
  });
};

/**
 * Show the current globalvalue
 */
exports.read = function (req, res) {
  // convert mongoose document to JSON
  var globalvalue = req.globalvalue ? req.globalvalue.toJSON() : {};

  // Add a custom field to the Globalvalue, for determining if the current User is the "owner".
  // NOTE: This field is NOT persisted to the database, since it doesn't exist in the Globalvalue model.
  globalvalue.isCurrentUserOwner = !!(req.user && globalvalue.user && globalvalue.user._id.toString() === req.user._id.toString());

  res.json(globalvalue);
};

/**
 * Update an globalvalue
 */
exports.update = function (req, res) {
  var globalvalue = req.globalvalue;
  globalvalue.title = req.body.title;
  globalvalue.value = req.body.value;

  globalvalue.save(function (err) {
    if (err) {
      return res.status(422).send({
        message: errorHandler.getErrorMessage(err)
      });
    } else {
      res.json(globalvalue);
    }
  });
};

/**
 * Delete an globalvalue
 */
exports.delete = function (req, res) {
  var globalvalue = req.globalvalue;

  globalvalue.remove(function (err) {
    if (err) {
      return res.status(422).send({
        message: errorHandler.getErrorMessage(err)
      });
    } else {
      res.json(globalvalue);
    }
  });
};

/**
 * List of Globalvalues
 */
exports.list = function (req, res) {
  Globalvalue.find().sort('created').populate('user', 'displayName').exec(function (err, globalvalues) {
    if (err) {
      return res.status(422).send({
        message: errorHandler.getErrorMessage(err)
      });
    } else {
      res.json(globalvalues);
    }
  });
};

/**
 * Globalvalue middleware
 */
exports.globalvalueByID = function (req, res, next, id) {

  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(400).send({
      message: 'Globalvalue is invalid'
    });
  }

  Globalvalue.findById(id).populate('user', 'displayName').exec(function (err, globalvalue) {
    if (err) {
      return next(err);
    } else if (!globalvalue) {
      return res.status(404).send({
        message: 'No globalvalue with that identifier has been found'
      });
    }
    req.globalvalue = globalvalue;
    next();
  });
};
