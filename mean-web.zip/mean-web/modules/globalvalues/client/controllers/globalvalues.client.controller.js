(function () {
  'use strict';

  angular
    .module('globalvalues')
    .controller('GlobalvaluesController', GlobalvaluesController);

  GlobalvaluesController.$inject = ['$scope', 'globalvalueResolve', 'Authentication'];

  function GlobalvaluesController($scope, globalvalue, Authentication) {
    var vm = this;

    vm.globalvalue = globalvalue;
    vm.authentication = Authentication;

  }
}());
