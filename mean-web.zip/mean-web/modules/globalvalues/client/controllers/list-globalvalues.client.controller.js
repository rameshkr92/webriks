(function () {
  'use strict';

  angular
    .module('globalvalues')
    .controller('GlobalvaluesListController', GlobalvaluesListController);

  GlobalvaluesListController.$inject = ['GlobalvaluesService'];

  function GlobalvaluesListController(GlobalvaluesService) {
    var vm = this;

    vm.globalvalues = GlobalvaluesService.query();
  }
}());
