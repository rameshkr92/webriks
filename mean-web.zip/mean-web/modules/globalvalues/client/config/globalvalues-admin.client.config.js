﻿(function () {
  'use strict';

  // Configuring the Globalvalues Admin module
  angular
    .module('globalvalues.admin')
    .run(menuConfig);

  menuConfig.$inject = ['menuService'];

  function menuConfig(Menus) {
    Menus.addSubMenuItem('topbar', 'admin', {
      title: 'Manage Globalvalues',
      state: 'admin.globalvalues.list'
    });
  }
}());
