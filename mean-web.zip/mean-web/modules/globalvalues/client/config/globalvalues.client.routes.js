(function () {
  'use strict';

  angular
    .module('globalvalues.routes')
    .config(routeConfig);

  routeConfig.$inject = ['$stateProvider'];

  function routeConfig($stateProvider) {
    $stateProvider
      .state('globalvalues', {
        abstract: true,
        url: '/globalvalues',
        template: '<ui-view/>'
      })
      .state('globalvalues.list', {
        url: '',
        templateUrl: '/modules/globalvalues/client/views/list-globalvalues.client.view.html',
        controller: 'GlobalvaluesListController',
        controllerAs: 'vm',
        data: {
          pageTitle: 'Globalvalues List'
        }
      })
      .state('globalvalues.view', {
        url: '/:globalvalueId',
        templateUrl: '/modules/globalvalues/client/views/view-globalvalue.client.view.html',
        controller: 'GlobalvaluesController',
        controllerAs: 'vm',
        resolve: {
          globalvalueResolve: getGlobalvalue
        },
        data: {
          pageTitle: 'Globalvalue {{ globalvalueResolve.title }}'
        }
      });
  }

  getGlobalvalue.$inject = ['$stateParams', 'GlobalvaluesService'];

  function getGlobalvalue($stateParams, GlobalvaluesService) {
    return GlobalvaluesService.get({
      globalvalueId: $stateParams.globalvalueId
    }).$promise;
  }
}());
