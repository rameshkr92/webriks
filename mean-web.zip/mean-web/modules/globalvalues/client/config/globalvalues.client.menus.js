(function () {
  'use strict';

  angular
    .module('globalvalues')
    .run(menuConfig);

  menuConfig.$inject = ['menuService'];

  function menuConfig(menuService) {
    menuService.addMenuItem('topbar', {
      title: 'Globalvalues',
      state: 'globalvalues',
      type: 'dropdown',
      roles: ['*']
    });

    // Add the dropdown list item
    menuService.addSubMenuItem('topbar', 'globalvalues', {
      title: 'List Globalvalues',
      state: 'globalvalues.list',
      roles: ['*']
    });
  }
}());
