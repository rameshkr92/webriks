﻿(function () {
  'use strict';

  angular
    .module('globalvalues.admin.routes')
    .config(routeConfig);

  routeConfig.$inject = ['$stateProvider'];

  function routeConfig($stateProvider) {
    $stateProvider
      .state('admin.globalvalues', {
        abstract: true,
        url: '/globalvalues',
        template: '<ui-view/>'
      })
      .state('admin.globalvalues.list', {
        url: '',
        templateUrl: '/modules/globalvalues/client/views/admin/list-globalvalues.client.view.html',
        controller: 'GlobalvaluesAdminListController',
        controllerAs: 'vm',
        data: {
          roles: ['admin']
        }
      })
      .state('admin.globalvalues.create', {
        url: '/create',
        templateUrl: '/modules/globalvalues/client/views/admin/form-globalvalue.client.view.html',
        controller: 'GlobalvaluesAdminController',
        controllerAs: 'vm',
        data: {
          roles: ['admin']
        },
        resolve: {
          globalvalueResolve: newGlobalvalue
        }
      })
       .state('admin.globalvalues.language', {
         url: '/:globalvalueId/language',
         templateUrl: '/modules/globalvalues/client/views/admin/form-globalvalue-multilang.client.view.html',
         controller: 'GlobalvaluesAdminController',
         controllerAs: 'vm',
         data: {
           roles: ['admin']
         },
         resolve: {
           globalvalueResolve: getGlobalvalue
         }
       })
      .state('admin.globalvalues.edit', {
        url: '/:globalvalueId/edit',
        templateUrl: '/modules/globalvalues/client/views/admin/form-globalvalue.client.view.html',
        controller: 'GlobalvaluesAdminController',
        controllerAs: 'vm',
        data: {
          roles: ['admin']
        },
        resolve: {
          globalvalueResolve: getGlobalvalue
        }
      });
  }

  getGlobalvalue.$inject = ['$stateParams', 'GlobalvaluesService'];

  function getGlobalvalue($stateParams, GlobalvaluesService) {
    return GlobalvaluesService.get({
      globalvalueId: $stateParams.globalvalueId
    }).$promise;
  }

  newGlobalvalue.$inject = ['GlobalvaluesService'];

  function newGlobalvalue(GlobalvaluesService) {
    return new GlobalvaluesService();
  }
}());
