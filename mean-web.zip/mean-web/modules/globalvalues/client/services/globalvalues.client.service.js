(function () {
  'use strict';

  angular
    .module('globalvalues.services')
    .factory('GlobalvaluesService', GlobalvaluesService);

  GlobalvaluesService.$inject = ['$resource', '$log'];

  function GlobalvaluesService($resource, $log) {
    var Globalvalue = $resource('/api/globalvalues/:globalvalueId', {
      globalvalueId: '@_id'
    }, {
      update: {
        method: 'PUT'
      },
      query: {
        method: 'GET',
        isArray: true
      }
    });

    angular.extend(Globalvalue.prototype, {
      createOrUpdate: function () {
        var globalvalue = this;
        return createOrUpdate(globalvalue);
      }
    });

    return Globalvalue;

    function createOrUpdate(globalvalue) {
      if (globalvalue._id) {
        return globalvalue.$update(onSuccess, onError);
      } else {
        return globalvalue.$save(onSuccess, onError);
      }

      // Handle successful response
      function onSuccess(globalvalue) {
        // Any required internal processing from inside the service, goes here.
      }

      // Handle error response
      function onError(errorResponse) {
        var error = errorResponse.data;
        // Handle error internally
        handleError(error);
      }
    }

    function handleError(error) {
      // Log error
      $log.error(error);
    }
  }
}());
