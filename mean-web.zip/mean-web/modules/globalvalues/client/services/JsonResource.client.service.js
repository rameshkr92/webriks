(function () {
  'use strict';

  angular
    .module('globalvalues.services')
    .factory('JsonResourceService', JsonResourceService);

  JsonResourceService.$inject = ['$resource', '$log'];

  function JsonResourceService($resource, $log) {
    return $resource('/api/globalvalues/', {}, {
      query: {
        method: 'GET',
        transformResponse: function(data) {
          return angular.fromJson(data).events;
        },
        isArray: true
      }
    });
  }
}());
