(function (app) {
  'use strict';

  app.registerModule('banners', ['core','smart-table','ui.tinymce']);// The core module is required for special route handling; see /core/client/config/core.client.routes
  app.registerModule('banners.admin', ['core.admin','smart-table','ui.tinymce']);
  app.registerModule('banners.admin.routes', ['core.admin.routes']);
  app.registerModule('banners.services');
  app.registerModule('banners.routes', ['ui.router', 'core.routes', 'banners.services']);
}(ApplicationConfiguration));
