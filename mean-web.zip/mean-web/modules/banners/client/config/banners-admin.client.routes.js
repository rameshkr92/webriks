﻿(function () {
  'use strict';

  angular
    .module('banners.admin.routes')
    .config(routeConfig);

  routeConfig.$inject = ['$stateProvider'];

  function routeConfig($stateProvider) {
    $stateProvider
      .state('admin.banners', {
        abstract: true,
        url: '/banners',
        template: '<ui-view/>'
      })
      .state('admin.banners.list', {
        url: '',
        templateUrl: '/modules/banners/client/views/admin/list-banners.client.view.html',
        controller: 'BannersAdminListController',
        controllerAs: 'vm',
        data: {
          roles: ['admin']
        }
      })
      .state('admin.banners.create', {
        url: '/create',
        templateUrl: '/modules/banners/client/views/admin/form-banner.client.view.html',
        controller: 'BannersAdminController',
        controllerAs: 'vm',
        data: {
          roles: ['admin']
        },
        resolve: {
          bannerResolve: newBanner
        }
      })
       .state('admin.banners.language', {
         url: '/:bannerId/language',
         templateUrl: '/modules/banners/client/views/admin/form-banner-multilang.client.view.html',
         controller: 'BannersAdminController',
         controllerAs: 'vm',
         data: {
           roles: ['admin']
         },
         resolve: {
           bannerResolve: getBanner
         }
       })
      .state('admin.banners.edit', {
        url: '/:bannerId/edit',
        templateUrl: '/modules/banners/client/views/admin/form-banner.client.view.html',
        controller: 'BannersAdminController',
        controllerAs: 'vm',
        data: {
          roles: ['admin']
        },
        resolve: {
          bannerResolve: getBanner
        }
      });
  }

  getBanner.$inject = ['$stateParams', 'BannersService'];

  function getBanner($stateParams, BannersService) {
    return BannersService.get({
      bannerId: $stateParams.bannerId
    }).$promise;
  }

  newBanner.$inject = ['BannersService'];

  function newBanner(BannersService) {
    return new BannersService();
  }
}());
