﻿(function () {
  'use strict';

  // Configuring the Articles Admin module
  angular
    .module('banners.admin')
    .run(menuConfig);

  menuConfig.$inject = ['menuService'];

  function menuConfig(Menus) {
    Menus.addSubMenuItem('topbar', 'admin', {
      title: 'Manage Banners',
      state: 'admin.banners.list'
    });
  }
}());
