(function () {
  'use strict';

  angular
    .module('banners')
    .run(menuConfig);

  menuConfig.$inject = ['menuService'];

  function menuConfig(menuService) {
    menuService.addMenuItem('topbar', {
      title: 'Banners',
      state: 'banners',
      type: 'dropdown',
      roles: ['*']
    });

    // Add the dropdown list item
    menuService.addSubMenuItem('topbar', 'banners', {
      title: 'List Banners',
      state: 'banners.list',
      roles: ['*']
    });
  }
}());
