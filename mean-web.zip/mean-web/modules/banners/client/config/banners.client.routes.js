(function () {
  'use strict';

  angular
    .module('banners.routes')
    .config(routeConfig);

  routeConfig.$inject = ['$stateProvider'];

  function routeConfig($stateProvider) {
    $stateProvider
      .state('banners', {
        abstract: true,
        url: '/banners',
        template: '<ui-view/>'
      })
      .state('banners.list', {
        url: '',
        templateUrl: '/modules/banners/client/views/list-banners.client.view.html',
        controller: 'BannersListController',
        controllerAs: 'vm',
        data: {
          pageTitle: 'Banners List'
        }
      })
      .state('banners.view', {
        url: '/:bannerId',
        templateUrl: '/modules/banners/client/views/view-banner.client.view.html',
        controller: 'BannersController',
        controllerAs: 'vm',
        resolve: {
          bannerResolve: getBanner
        },
        data: {
          pageTitle: 'Banner {{ bannerResolve.title }}'
        }
      });
  }

  getBanner.$inject = ['$stateParams', 'BannersService'];

  function getBanner($stateParams, BannersService) {
    return BannersService.get({
      bannerId: $stateParams.bannerId
    }).$promise;
  }
}());
