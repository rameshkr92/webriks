(function () {
  'use strict';

  angular
    .module('banners')
    .controller('BannersController', BannersController);

  BannersController.$inject = ['$scope', 'bannerResolve', 'Authentication'];

  function BannersController($scope, banner, Authentication) {
    var vm = this;

    vm.banner = banner;
    vm.authentication = Authentication;

  }
}());
