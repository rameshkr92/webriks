(function () {
  'use strict';

  angular
    .module('banners')
    .controller('BannersListController', BannersListController);

  BannersListController.$inject = ['BannersService'];

  function BannersListController(BannersService) {
    var vm = this;

    vm.banners = BannersService.query();
  }
}());
