(function () {
  'use strict';

  angular
    .module('banners.services')
    .factory('JsonResourceBanner', JsonResourceBanner);

  JsonResourceBanner.$inject = ['$resource', '$log'];
  function JsonResourceBanner($resource, $log) {
    return $resource('/api/banners/', {}, {
      query: {
        method: 'GET',
        transformResponse: function(data) {
          return angular.fromJson(data).events;
        },
        isArray: true
      }
    });
  }
}());
