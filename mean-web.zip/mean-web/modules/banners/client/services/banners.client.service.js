(function () {
  'use strict';

  angular
    .module('banners.services')
    .factory('BannersService', BannersService);

  BannersService.$inject = ['$resource', '$log'];

  function BannersService($resource, $log) {
    var Service = $resource('/api/banners/:bannerId', {
      bannerId: '@_id'
    }, {
      update: {
        method: 'PUT'
      },
      query: {
        method: 'GET',
        isArray: true
      }
    });

    angular.extend(Service.prototype, {
      createOrUpdate: function () {
        var banner = this;
        return createOrUpdate(banner);
      }
    });

    return Service;

    function createOrUpdate(banner) {
      if (banner._id) {
        return banner.$update(onSuccess, onError);
      } else {
        return banner.$save(onSuccess, onError);
      }

      // Handle successful response
      function onSuccess(banner) {
        // Any required internal processing from inside the banner, goes here.
      }

      // Handle error response
      function onError(errorResponse) {
        var error = errorResponse.data;
        // Handle error internally
        handleError(error);
      }
    }

    function handleError(error) {
      // Log error
      $log.error(error);
    }
  }
}());
