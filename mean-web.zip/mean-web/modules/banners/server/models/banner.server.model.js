'use strict';

/**
 * Module dependencies
 */
var mongoose = require('mongoose'),
  Schema = mongoose.Schema;

/**
 * Service Schema
 */
var BannerSchema = new Schema({
  created: {
    type: Date,
    default: Date.now
  },
 
 title:{
        en: {
        type: String,
        default: '',
        required: 'Please fill global value title',
        trim: true
            },
        ar : {
            type: String,
            default: '',
            trim: true
        }
 },
 text_description:{
        en: {
        type: String,
        default: '',
        trim: true
       },
        ar : {
            type: String,
            default: '',
            trim: true
        }
 },
 link_url: {
    type: String,
    default:''
  },
 image: {
    type: String,
    default: ''
  },
  user: {
    type: Schema.ObjectId,
    ref: 'User'
  }
});

mongoose.model('Banner', BannerSchema);
