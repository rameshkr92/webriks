'use strict';

/**
 * Module dependencies
 */
var path = require('path'),
   fs = require('fs'),
  multer = require('multer'),
  config = require(path.resolve('./config/config')),
  mongoose = require('mongoose'),
  Banner = mongoose.model('Banner'),
  errorHandler = require(path.resolve('./modules/core/server/controllers/errors.server.controller'));

/**
 * Create an banner
 */
exports.create = function (req, res) {
  
  var banner = new Banner(req.body);
  banner.user = req.body.user;
  
    banner.save(function (err) {
    if (err) {
      return res.status(422).send({
        message: errorHandler.getErrorMessage(err)
      });
    } else {
      res.json(banner);
    }
  });
};
exports.changeProfilePicture = function (req, res) {
  var user = req.user;
  //var existingImageUrl;

  // Filtering to upload only images
  var multerConfig = config.uploads.banners_images.image;
  multerConfig.fileFilter = require(path.resolve('./config/lib/multer')).imageFileFilter;
  var upload = multer(multerConfig).single('newBannerPicture');

  if (user) {
    //existingImageUrl = user.image;
    //user.imagePath=config.uploads.banners_images.image.dest + req.file.filename;
    uploadImage()
   
     // .then(updateUser)
    //  .then(deleteOldImage)
      .then(function () {
          var uploadPath=config.uploads.banners_images.image.dest+req.file.filename;
        res.json(uploadPath);
      })
      .catch(function (err) {
        res.status(422).send(err);
      });
  } else {
    res.status(401).send({
      message: 'User is not signed in'
    });
  }

  function uploadImage () {
    return new Promise(function (resolve, reject) {
      upload(req, res, function (uploadError) {
        if (uploadError) {
          reject(errorHandler.getErrorMessage(uploadError));
        } else {
          resolve();
        }
      });
    });
  }

};
/**
 * Show the current banner
 */
exports.read = function (req, res) {
  // convert mongoose document to JSON
  var banner = req.banner ? req.banner.toJSON() : {};

  // Add a custom field to the Banner, for determining if the current User is the "owner".
  // NOTE: This field is NOT persisted to the database, since it doesn't exist in the Banner model.
  banner.isCurrentUserOwner = !!(req.user && banner.user && banner.user._id.toString() === req.user._id.toString());

  res.json(banner);
};

/**
 * Update an banner
 */
exports.update = function (req, res) {
   
  var banner = req.banner;
  banner.title = req.body.title;
  banner.text_description = req.body.text_description;
  if(req.body.parentId === '')
  {
       banner.parentId = null;
  }else{
       banner.parentId =req.body.parentId ;
  }
  if(req.body.image !== '')
  {
    banner.image =req.body.image ;
  }
 
  

  banner.save(function (err) {
    if (err) {
      return res.status(422).send({
        message: errorHandler.getErrorMessage(err)
      });
    } else {
      res.json(banner);
    }
  });
};

/**
 * Delete an banner
 */
exports.delete = function (req, res) {
  var banner = req.banner;

  banner.remove(function (err) {
    if (err) {
      return res.status(422).send({
        message: errorHandler.getErrorMessage(err)
      });
    } else {
      res.json(banner);
    }
  });
};

/**
 * List of Banners
 */
exports.list = function (req, res) {
  Banner.find().sort('-created').populate('user', 'displayName').populate('parentId', 'title').exec(function (err, banners) {
    if (err) {
      return res.status(422).send({
        message: errorHandler.getErrorMessage(err)
      });
    } else {
      res.json(banners);
    }
  });
};

/**
 * Banner middleware
 */
exports.bannerByID = function (req, res, next, id) {

  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(400).send({
      message: 'Banner is invalid'
    });
  }

  Banner.findById(id).populate('user', 'displayName').exec(function (err, banner) {
    if (err) {
      return next(err);
    } else if (!banner) {
      return res.status(404).send({
        message: 'No banner with that identifier has been found'
      });
    }
    req.banner = banner;
    next();
  });
};
