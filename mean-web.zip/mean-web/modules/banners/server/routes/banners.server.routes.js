'use strict';

/**
 * Module dependencies
 */
var bannersPolicy = require('../policies/banners.server.policy'),
  banners = require('../controllers/banners.server.controller');

module.exports = function (app) {
  // Banners collection routes
  app.route('/api/banners/picture').post(banners.changeProfilePicture);
  app.route('/api/banners').all(bannersPolicy.isAllowed)
    .get(banners.list)
    .post(banners.create);
  // Single banner routes
  app.route('/api/banners/:bannerId').all(bannersPolicy.isAllowed)
    .get(banners.read)
    .put(banners.update)
    .delete(banners.delete);


  // Finish by binding the banner middleware
  app.param('bannerId', banners.bannerByID);
};
