﻿'use strict';

var should = require('should'),
  request = require('supertest'),
  path = require('path'),
  mongoose = require('mongoose'),
  User = mongoose.model('User'),
  Banner = mongoose.model('Banner'),
  express = require(path.resolve('./config/lib/express'));

/**
 * Globals
 */
var app,
  agent,
  credentials,
  user,
  banner;

/**
 * Banner routes tests
 */
describe('Banner Admin CRUD tests', function () {
  before(function (done) {
    // Get application
    app = express.init(mongoose);
    agent = request.agent(app);

    done();
  });

  beforeEach(function (done) {
    // Create user credentials
    credentials = {
      usernameOrEmail: 'username',
      password: 'M3@n.jsI$Aw3$0m3'
    };

    // Create a new user
    user = new User({
      firstName: 'Full',
      lastName: 'Name',
      displayName: 'Full Name',
      email: 'test@test.com',
      roles: ['user', 'admin'],
      username: credentials.usernameOrEmail,
      password: credentials.password,
      provider: 'local'
    });

    // Save a user to the test db and create new banner
    user.save(function () {
      banner = {
        title: 'Banner Title',
        content: 'Banner Content'
      };

      done();
    });
  });

  it('should be able to save an banner if logged in', function (done) {
    agent.post('/api/auth/signin')
      .send(credentials)
      .expect(200)
      .end(function (signinErr, signinRes) {
        // Handle signin error
        if (signinErr) {
          return done(signinErr);
        }

        // Get the userId
        var userId = user.id;

        // Save a new banner
        agent.post('/api/banners')
          .send(banner)
          .expect(200)
          .end(function (bannerSaveErr, bannerSaveRes) {
            // Handle banner save error
            if (bannerSaveErr) {
              return done(bannerSaveErr);
            }

            // Get a list of banners
            agent.get('/api/banners')
              .end(function (bannersGetErr, bannersGetRes) {
                // Handle banner save error
                if (bannersGetErr) {
                  return done(bannersGetErr);
                }

                // Get banners list
                var banners = bannersGetRes.body;

                // Set assertions
                (banners[0].user._id).should.equal(userId);
                (banners[0].title).should.match('Banner Title');

                // Call the assertion callback
                done();
              });
          });
      });
  });

  it('should be able to update an banner if signed in', function (done) {
    agent.post('/api/auth/signin')
      .send(credentials)
      .expect(200)
      .end(function (signinErr, signinRes) {
        // Handle signin error
        if (signinErr) {
          return done(signinErr);
        }

        // Get the userId
        var userId = user.id;

        // Save a new banner
        agent.post('/api/banners')
          .send(banner)
          .expect(200)
          .end(function (bannerSaveErr, bannerSaveRes) {
            // Handle banner save error
            if (bannerSaveErr) {
              return done(bannerSaveErr);
            }

            // Update banner title
            banner.title = 'WHY YOU GOTTA BE SO MEAN?';

            // Update an existing banner
            agent.put('/api/banners/' + bannerSaveRes.body._id)
              .send(banner)
              .expect(200)
              .end(function (bannerUpdateErr, bannerUpdateRes) {
                // Handle banner update error
                if (bannerUpdateErr) {
                  return done(bannerUpdateErr);
                }

                // Set assertions
                (bannerUpdateRes.body._id).should.equal(bannerSaveRes.body._id);
                (bannerUpdateRes.body.title).should.match('WHY YOU GOTTA BE SO MEAN?');

                // Call the assertion callback
                done();
              });
          });
      });
  });

  it('should not be able to save an banner if no title is provided', function (done) {
    // Invalidate title field
    banner.title = '';

    agent.post('/api/auth/signin')
      .send(credentials)
      .expect(200)
      .end(function (signinErr, signinRes) {
        // Handle signin error
        if (signinErr) {
          return done(signinErr);
        }

        // Get the userId
        var userId = user.id;

        // Save a new banner
        agent.post('/api/banners')
          .send(banner)
          .expect(422)
          .end(function (bannerSaveErr, bannerSaveRes) {
            // Set message assertion
            (bannerSaveRes.body.message).should.match('Title cannot be blank');

            // Handle banner save error
            done(bannerSaveErr);
          });
      });
  });

  it('should be able to delete an banner if signed in', function (done) {
    agent.post('/api/auth/signin')
      .send(credentials)
      .expect(200)
      .end(function (signinErr, signinRes) {
        // Handle signin error
        if (signinErr) {
          return done(signinErr);
        }

        // Get the userId
        var userId = user.id;

        // Save a new banner
        agent.post('/api/banners')
          .send(banner)
          .expect(200)
          .end(function (bannerSaveErr, bannerSaveRes) {
            // Handle banner save error
            if (bannerSaveErr) {
              return done(bannerSaveErr);
            }

            // Delete an existing banner
            agent.delete('/api/banners/' + bannerSaveRes.body._id)
              .send(banner)
              .expect(200)
              .end(function (bannerDeleteErr, bannerDeleteRes) {
                // Handle banner error error
                if (bannerDeleteErr) {
                  return done(bannerDeleteErr);
                }

                // Set assertions
                (bannerDeleteRes.body._id).should.equal(bannerSaveRes.body._id);

                // Call the assertion callback
                done();
              });
          });
      });
  });

  it('should be able to get a single banner if signed in and verify the custom "isCurrentUserOwner" field is set to "true"', function (done) {
    // Create new banner model instance
    banner.user = user;
    var bannerObj = new Banner(banner);

    agent.post('/api/auth/signin')
      .send(credentials)
      .expect(200)
      .end(function (signinErr, signinRes) {
        // Handle signin error
        if (signinErr) {
          return done(signinErr);
        }

        // Get the userId
        var userId = user.id;

        // Save a new banner
        agent.post('/api/banners')
          .send(banner)
          .expect(200)
          .end(function (bannerSaveErr, bannerSaveRes) {
            // Handle banner save error
            if (bannerSaveErr) {
              return done(bannerSaveErr);
            }

            // Get the banner
            agent.get('/api/banners/' + bannerSaveRes.body._id)
              .expect(200)
              .end(function (bannerInfoErr, bannerInfoRes) {
                // Handle banner error
                if (bannerInfoErr) {
                  return done(bannerInfoErr);
                }

                // Set assertions
                (bannerInfoRes.body._id).should.equal(bannerSaveRes.body._id);
                (bannerInfoRes.body.title).should.equal(banner.title);

                // Assert that the "isCurrentUserOwner" field is set to true since the current User created it
                (bannerInfoRes.body.isCurrentUserOwner).should.equal(true);

                // Call the assertion callback
                done();
              });
          });
      });
  });

  afterEach(function (done) {
    User.remove().exec(function () {
      Banner.remove().exec(done);
    });
  });
});
