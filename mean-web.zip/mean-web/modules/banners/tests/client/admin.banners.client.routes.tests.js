﻿(function () {
  'use strict';

  describe('Banners Route Tests', function () {
    // Initialize global variables
    var $scope,
      BannersService;

    // We can start by loading the main application module
    beforeEach(module(ApplicationConfiguration.applicationModuleName));

    // The injector ignores leading and trailing underscores here (i.e. _$httpBackend_).
    // This allows us to inject a banner but then attach it to a variable
    // with the same name as the banner.
    beforeEach(inject(function ($rootScope, _BannersService_) {
      // Set a new global scope
      $scope = $rootScope.$new();
      BannersService = _BannersService_;
    }));

    describe('Route Config', function () {
      describe('Main Route', function () {
        var mainstate;
        beforeEach(inject(function ($state) {
          mainstate = $state.get('admin.banners');
        }));

        it('Should have the correct URL', function () {
          expect(mainstate.url).toEqual('/banners');
        });

        it('Should be abstract', function () {
          expect(mainstate.abstract).toBe(true);
        });

        it('Should have template', function () {
          expect(mainstate.template).toBe('<ui-view/>');
        });
      });

      describe('List Route', function () {
        var liststate;
        beforeEach(inject(function ($state) {
          liststate = $state.get('admin.banners.list');
        }));

        it('Should have the correct URL', function () {
          expect(liststate.url).toEqual('');
        });

        it('Should be not abstract', function () {
          expect(liststate.abstract).toBe(undefined);
        });

        it('Should have templateUrl', function () {
          expect(liststate.templateUrl).toBe('/modules/banners/client/views/admin/list-banners.client.view.html');
        });
      });

      describe('Create Route', function () {
        var createstate,
          BannersAdminController,
          mockBanner;

        beforeEach(inject(function ($controller, $state, $templateCache) {
          createstate = $state.get('admin.banners.create');
          $templateCache.put('/modules/banners/client/views/admin/form-banner.client.view.html', '');

          // Create mock banner
          mockBanner = new BannersService();

          // Initialize Controller
          BannersAdminController = $controller('BannersAdminController as vm', {
            $scope: $scope,
            bannerResolve: mockBanner
          });
        }));

        it('Should have the correct URL', function () {
          expect(createstate.url).toEqual('/create');
        });

        it('Should have a resolve function', function () {
          expect(typeof createstate.resolve).toEqual('object');
          expect(typeof createstate.resolve.bannerResolve).toEqual('function');
        });

        it('should respond to URL', inject(function ($state) {
          expect($state.href(createstate)).toEqual('/admin/banners/create');
        }));

        it('should attach an banner to the controller scope', function () {
          expect($scope.vm.banner._id).toBe(mockBanner._id);
          expect($scope.vm.banner._id).toBe(undefined);
        });

        it('Should not be abstract', function () {
          expect(createstate.abstract).toBe(undefined);
        });

        it('Should have templateUrl', function () {
          expect(createstate.templateUrl).toBe('/modules/banners/client/views/admin/form-banner.client.view.html');
        });
      });

      describe('Edit Route', function () {
        var editstate,
          BannersAdminController,
          mockBanner;

        beforeEach(inject(function ($controller, $state, $templateCache) {
          editstate = $state.get('admin.banners.edit');
          $templateCache.put('/modules/banners/client/views/admin/form-banner.client.view.html', '');

          // Create mock banner
          mockBanner = new BannersService({
            _id: '525a8422f6d0f87f0e407a33',
            title: 'An Banner about MEAN',
            content: 'MEAN rocks!'
          });

          // Initialize Controller
          BannersAdminController = $controller('BannersAdminController as vm', {
            $scope: $scope,
            bannerResolve: mockBanner
          });
        }));

        it('Should have the correct URL', function () {
          expect(editstate.url).toEqual('/:bannerId/edit');
        });

        it('Should have a resolve function', function () {
          expect(typeof editstate.resolve).toEqual('object');
          expect(typeof editstate.resolve.bannerResolve).toEqual('function');
        });

        it('should respond to URL', inject(function ($state) {
          expect($state.href(editstate, {
            bannerId: 1
          })).toEqual('/admin/banners/1/edit');
        }));

        it('should attach an banner to the controller scope', function () {
          expect($scope.vm.banner._id).toBe(mockBanner._id);
        });

        it('Should not be abstract', function () {
          expect(editstate.abstract).toBe(undefined);
        });

        it('Should have templateUrl', function () {
          expect(editstate.templateUrl).toBe('/modules/banners/client/views/admin/form-banner.client.view.html');
        });

        xit('Should go to unauthorized route', function () {

        });
      });

    });
  });
}());
