(function () {
  'use strict';

  describe('Banners List Controller Tests', function () {
    // Initialize global variables
    var BannersListController,
      $scope,
      $httpBackend,
      $state,
      Authentication,
      BannersService,
      mockBanner;

    // The $resource banner augments the response object with methods for updating and deleting the resource.
    // If we were to use the standard toEqual matcher, our tests would fail because the test values would not match
    // the responses exactly. To solve the problem, we define a new toEqualData Jasmine matcher.
    // When the toEqualData matcher compares two objects, it takes only object properties into
    // account and ignores methods.
    beforeEach(function () {
      jasmine.addMatchers({
        toEqualData: function (util, customEqualityTesters) {
          return {
            compare: function (actual, expected) {
              return {
                pass: angular.equals(actual, expected)
              };
            }
          };
        }
      });
    });

    // Then we can start by loading the main application module
    beforeEach(module(ApplicationConfiguration.applicationModuleName));

    // The injector ignores leading and trailing underscores here (i.e. _$httpBackend_).
    // This allows us to inject a banner but then attach it to a variable
    // with the same name as the banner.
    beforeEach(inject(function ($controller, $rootScope, _$state_, _$httpBackend_, _Authentication_, _BannersService_) {
      // Set a new global scope
      $scope = $rootScope.$new();

      // Point global variables to injected banners
      $httpBackend = _$httpBackend_;
      $state = _$state_;
      Authentication = _Authentication_;
      BannersService = _BannersService_;

      // create mock banner
      mockBanner = new BannersService({
        _id: '525a8422f6d0f87f0e407a33',
        title: 'An Banner about MEAN',
        content: 'MEAN rocks!'
      });

      // Mock logged in user
      Authentication.user = {
        roles: ['user']
      };

      // Initialize the Banners List controller.
      BannersListController = $controller('BannersListController as vm', {
        $scope: $scope
      });

      // Spy on state go
      spyOn($state, 'go');
    }));

    describe('Instantiate', function () {
      var mockBannerList;

      beforeEach(function () {
        mockBannerList = [mockBanner, mockBanner];
      });

      it('should send a GET request and return all banners', inject(function (BannersService) {
        // Set POST response
        $httpBackend.expectGET('/api/banners').respond(mockBannerList);

        // Ignore parent template get on state transition
        $httpBackend.whenGET('/modules/core/client/views/home.client.view.html').respond(200, '');

        $httpBackend.flush();

        // Test form inputs are reset
        expect($scope.vm.banners.length).toEqual(2);
        expect($scope.vm.banners[0]).toEqual(mockBanner);
        expect($scope.vm.banners[1]).toEqual(mockBanner);

      }));
    });
  });
}());
