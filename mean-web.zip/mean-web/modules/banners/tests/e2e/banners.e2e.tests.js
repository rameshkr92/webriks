'use strict';

describe('Banners E2E Tests:', function () {
  describe('Test banners page', function () {
    it('Should report missing credentials', function () {
      browser.get('http://localhost:3001/banners');
      expect(element.all(by.repeater('banner in banners')).count()).toEqual(0);
    });
  });
});
