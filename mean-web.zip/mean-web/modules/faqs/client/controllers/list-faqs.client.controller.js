(function () {
  'use strict';

  angular
    .module('faqs')
    .controller('FaqsListController', FaqsListController);

  FaqsListController.$inject = ['FaqsService'];

  function FaqsListController(FaqsService) {
    var vm = this;
     (FaqsService.query(function(data) {
    // angular.each(data,function(){})
    // vm.tblData = angular.toJson(data)
      vm.tblData = JSON.parse(angular.toJson(data));
      vm.stTblData = [];
      /* console.log(theData);*/
      angular.forEach(vm.tblData, function(ele, indx) {
        vm.stTblData.push({ 'content': ele.answer.en, 'title': ele.question.en, '_id': ele._id });
      });
    }));
  }
}());
