(function () {
  'use strict';

  angular
    .module('faqs.services')
    .factory('JsonResourceService', JsonResourceService);

  JsonResourceService.$inject = ['$resource', '$log'];

  function JsonResourceService($resource, $log) {
   return $resource('/api/faqs/', {}, {
        query: {
          method: 'GET',
          transformResponse: function(data) {
            return angular.fromJson(data).events;
          },
          isArray: true
        }
   });
   
  }
}());
