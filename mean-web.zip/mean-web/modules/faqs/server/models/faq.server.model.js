'use strict';

/**
 * Module dependencies
 */
var mongoose = require('mongoose'),
  Schema = mongoose.Schema;

/**
 * Faq Schema
 */
var FaqSchema = new Schema({
  created: {
    type: Date,
    default: Date.now
  },
  question:{
        en: {
        type: String,
        default: '',
        required: 'Please fill faq question',
        trim: true
        },
        ar: {
            type: String,
            default: '',
            trim: true
        }
 },
  answer:{
        en: {
        type: String,
        default: '',
        required: 'Please fill faq answer',
        trim: true
        },
        ar : {
            type: String,
            default: '',
            trim: true
        }
 },
  user: {
    type: Schema.ObjectId,
    ref: 'User'
  }
});

mongoose.model('Faq', FaqSchema);
