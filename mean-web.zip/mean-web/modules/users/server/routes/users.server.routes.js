'use strict';

module.exports = function (app) {
  // User Routes
  var users = require('../controllers/users.server.controller');

  // Setting up the users profile api
  app.route('/api/users/me').get(users.me);
  app.route('/api/users').put(users.update);
  app.route('/api/users/accounts').delete(users.removeOAuthProvider);
  app.route('/api/users/password').post(users.changePassword);
  app.route('/api/send-otp-to-user').post(users.sendOtpUser);
  app.route('/api/verify-otp').post(users.verifyOtp);
  app.route('/api/users/picture').post(users.changeProfilePicture);
//app.route('/api/service/picture').post(servicesPolicy.isAllowed,services.changeProfilePicture);
  // Finish by binding the user middleware
  app.param('userId', users.userByID);
};
