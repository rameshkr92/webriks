(function () {
  'use strict';

  // Setting up route
  angular
    .module('users.admin.routes')
    .config(routeConfig);
  routeConfig.$inject = ['$stateProvider'];

  function routeConfig($stateProvider) {
    $stateProvider
    .state('admin.settings', {
      abstract: true,
      url: '/settings',
      templateUrl: '/modules/users/client/views/admin-settings/settings.client.view.html',
      controller: 'SettingsController',
      controllerAs: 'vm',
      data: {
        roles: ['user', 'admin']
      }
    })
    .state('admin.settings.profile', {
      url: '/profile',
      templateUrl: '/modules/users/client/views/admin-settings/edit-profile.client.view.html',
      controller: 'EditProfileController',
      controllerAs: 'vm',
      data: {
        pageTitle: 'Update Profile'
      }
    })
    .state('admin.settings.password', {
      url: '/password',
      templateUrl: '/modules/users/client/views/admin-settings/change-password.client.view.html',
      controller: 'ChangePasswordController',
      controllerAs: 'vm',
      data: {
        pageTitle: 'Update password'
      }
    })
    .state('admin.settings.picture', {
      url: '/picture',
      templateUrl: '/modules/users/client/views/admin-settings/change-profile-picture.client.view.html',
      controller: 'ChangeProfilePictureController',
      controllerAs: 'vm',
      data: {
        pageTitle: 'Update picture'
      }
    })
    .state('admin.dashboard', {
      url: '/dashboard',
      templateUrl: '/modules/users/client/views/admin/admin-dashboard.client.view.html',
      controller: 'UserListController',
      controllerAs: 'vm',
      sidebarMeta: {
        icon: 'ion-document',
        order: 0
      },
      data: {
        roles: ['admin']
      }
    })
    .state('admin.managerdashboard', {
      url: '/managerdashboard',
      templateUrl: '/modules/users/client/views/admin/admin-managerdashboard.client.view.html',
      controller: 'AreaManagerListController',
      controllerAs: 'vm',
      sidebarMeta: {
        icon: 'ion-document',
        order: 0
      },
      data: {
        roles: ['areamanager', 'admin']
      }
    })
    .state('admin.users', {
      url: '/users',
      templateUrl: '/modules/users/client/views/admin/list-users.client.view.html',
      controller: 'UserListController',
      controllerAs: 'vm',
      data: {
        pageTitle: 'Users List'
      }
    })
    .state('admin.customers', {
      url: '/customers',
      templateUrl: '/modules/users/client/views/admin/list-customers.client.view.html',
      controller: 'CustomerListController',
      controllerAs: 'vm',
      data: {
        pageTitle: 'Users List'
      }
    })
    .state('admin.area-managers', {
      url: '/area-managers',
      templateUrl: '/modules/users/client/views/admin/list-area-managers.client.view.html',
      controller: 'AreaManagerListController',
      controllerAs: 'vm',
      data:{
        pageTitle: 'Users List'
      }
    })
    .state('admin.controllers', {
      url: '/controllers',
      templateUrl: '/modules/users/client/views/admin/list-controllers.client.view.html',
      controller: 'ControllerListController',
      controllerAs: 'vm',
      data:{
        pageTitle: 'Controller Users List',
        roles: ['areamanager', 'admin']
      }
    })
    .state('admin.technicians', {
      url: '/technicians',
      templateUrl: '/modules/users/client/views/admin/list-technicians.client.view.html',
      controller: 'TechniciansListController',
      controllerAs: 'vm',
      data:{
        pageTitle: 'Users List',
         roles: ['areamanager', 'admin','controller']
      }
    })
    .state('admin.user', {
      url: '/users/:userId',
      templateUrl: '/modules/users/client/views/admin/view-user.client.view.html',
      controller: 'UserController',
      controllerAs: 'vm',
      resolve: {
        userResolve: getUser
      },
      data: {
        pageTitle: 'Edit {{ userResolve.displayName }}'
      }
    })
    .state('admin.customer', {
      url: '/customer/:userId',
      templateUrl: '/modules/users/client/views/admin/view-customer.client.view.html',
      controller: 'UserController',
      controllerAs: 'vm',
      resolve: {
        userResolve: getUser
      },
      data: {
        pageTitle: 'Edit {{ userResolve.displayName }}'
      }
    })
    .state('admin.technician', {
      url: '/technician/:userId',
      templateUrl: '/modules/users/client/views/admin/view-technician.client.view.html',
      controller: 'TechnicianUserController',
      controllerAs: 'vm',
      resolve: {
        userResolve: getUser
      },
      data: {
        pageTitle: 'Edit {{ userResolve.displayName }}',
        roles: ['areamanager', 'admin', 'controller']
      }
    })
    .state('admin.areamanager', {
      url: '/areamanager/:userId',
      templateUrl: '/modules/users/client/views/admin/view-areamanager.client.view.html',
      controller: 'UserController',
      controllerAs: 'vm',
      resolve: {
        userResolve: getUser
      },
      data: {
        pageTitle: 'Edit {{ userResolve.displayName }}'
      }
    })
    .state('admin.user-create', {
      url: '/user-create',
      templateUrl: '/modules/users/client/views/admin/create-user.client.view.html',
      controller: 'UserController',
      controllerAs: 'vm',
      data: {
        pageTitle: 'Create admin user'
      },
      resolve: {
        userResolve: getUserDetails
      }
    })
    .state('admin.create-customer', {
      url: '/create-customer',
      templateUrl: '/modules/users/client/views/admin/create-customer.client.view.html',
      controller: 'UserController',
      controllerAs: 'vm',
      data: {
        pageTitle: 'Create Customer'
      },
      resolve: {
        userResolve: getUserDetails
      }
    })
    .state('admin.create-area-manager', {
      url: '/create-area-manager',
      templateUrl: '/modules/users/client/views/admin/create-manager.client.view.html',
      controller: 'UserController',
      controllerAs: 'vm',
      data: {
        pageTitle: 'Create Area Manager'
      },
      resolve: {
        userResolve: getUserDetails
      }
    })
    .state('admin.create-controller', {
      url: '/create-controller',
      templateUrl: '/modules/users/client/views/admin/create-controller.client.view.html',
      controller: 'ControllerUserController',
      controllerAs: 'vm',
      data: {
        pageTitle: 'Create Controller',
        roles: ['areamanager', 'admin']
      },
      resolve: {
        userResolve: getControllerDetails
      }
    })
    .state('admin.create-technician', {
      url: '/create-technician',
      templateUrl: '/modules/users/client/views/admin/create-technician.client.view.html',
      controller: 'TechnicianUserController',
      controllerAs: 'vm',
      data: {
        pageTitle: 'Create Technician',
        roles: ['areamanager', 'admin','controller']
      },
      resolve: {
        userResolve: getTechnicianDetails
      }
    })
    .state('admin.user-edit', {
      url: '/users/:userId/edit',
      templateUrl: '/modules/users/client/views/admin/edit-user.client.view.html',
      controller: 'UserController',
      controllerAs: 'vm',
      resolve: {
        userResolve: getUser
      },
      data: {
        pageTitle: 'Edit User {{ userResolve.displayName }}'
      }
    })
    .state('admin.controller-edit', {
      url: '/controller/:userId/edit',
      templateUrl: '/modules/users/client/views/admin/edit-controller.client.view.html',
      controller: 'ControllerUserController',
      controllerAs: 'vm',
      resolve: {
        userResolve: getUser
      },
      
      data: {
        pageTitle: 'Edit Customer {{ userResolve.displayName }}',
        roles: ['areamanager', 'admin']
      }
    })
    .state('admin.customer-edit', {
      url: '/customer/:userId/edit',
      templateUrl: '/modules/users/client/views/admin/edit-customer.client.view.html',
      controller: 'UserController',
      controllerAs: 'vm',
      resolve: {
        userResolve: getUser
      },
      data: {
        pageTitle: 'Edit Customer {{ userResolve.displayName }}'
      }
    })
    .state('admin.technician-edit', {
      url: '/technician/:userId/edit',
      templateUrl: '/modules/users/client/views/admin/edit-technician.client.view.html',
      controller: 'TechnicianUserController',
      controllerAs: 'vm',
      resolve: {
        userResolve: getUser
      },
      data: {
        pageTitle: 'Edit Customer {{ userResolve.displayName }}',
        roles: ['areamanager', 'admin','controller']
      }
    })
    
    .state('admin.areamanager-edit', {
      url: '/areamanager/:userId/edit',
      templateUrl: '/modules/users/client/views/admin/edit-areamanager.client.view.html',
      controller: 'UserController',
      controllerAs: 'vm',
      resolve: {
        userResolve: getUser
      },
      data: {
        pageTitle: 'Edit Areamanager {{ userResolve.displayName }}'
      }
    });
    getUser.$inject = ['$stateParams', 'AdminService','ControllersService','TechniciansService'];
    function getUser($stateParams, AdminService) {
      return AdminService.get({
        userId: $stateParams.userId
      }).$promise;
    }
    function getUserDetails($stateParams, AdminService) {
      return AdminService.query().$promise;
    }
    function getControllerDetails($stateParams, ControllersService) {
      return ControllersService.query().$promise;
    }
    function getTechnicianDetails($stateParams, TechniciansService) {
      return TechniciansService.query().$promise;
    }
  }
}());
