(function () {
  'use strict';
  angular
    .module('users')
    .controller('AuthenticationController', AuthenticationController);

  AuthenticationController.$inject = ['$scope', '$timeout', '$state', 'UsersService', '$location', '$window', 'Authentication', 'PasswordValidator', 'Notification', '$http'];

  function AuthenticationController($scope, $timeout, $state, UsersService, $location, $window, Authentication, PasswordValidator, Notification, $http) {
    var vm = this;
    vm.authentication = Authentication;
    vm.getPopoverMsg = PasswordValidator.getPopoverMsg;
    vm.signup = signup;
    vm.signin = signin;
    vm.adminsignin = adminsignin;
    vm.callOauthProvider = callOauthProvider;
    vm.usernameRegex = /^(?=[\w.-]+$)(?!.*[._-]{2})(?!\.)(?!.*\.$).{3,34}$/;
    // Get an eventual error defined in the URL query string:
    if ($location.search().err) {
      Notification.error({ message: $location.search().err });
    }
    // If user is signed in then redirect back home
    if (vm.authentication.user) {
      if (vm.authentication.user.roles[0] === 'admin' || vm.authentication.user.roles[0] === 'areamanager' ||vm.authentication.user.roles[0] === 'controller') {
        window.location = '/admin/dashboard';
      } 
    }
    vm.site_email = '';
    $http.get('/api/globalvalues').success(function(data) {
      // process response here..
     vm.site_email=data[0].value.en;
    });
    var latitude=0;
    var longtitude=0;
     $timeout( function(){
           if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function (position) {
            
                latitude = position.coords.latitude; 
                longtitude= position.coords.longitude;
                
        });
        
     }
    }, 2000 );
    function signup(isValid) {
      if (!isValid) {
        $scope.$broadcast('show-errors-check-validity', 'vm.userForm');
        return false;
      }
     vm.credentials.userLat =latitude;
     vm.credentials.userLong = longtitude;
     vm.credentials.usercurrentLat =latitude;
     vm.credentials.usercurrentLong = longtitude;
     vm.credentials.site_email = vm.site_email;
     vm.credentials.subject = 'Your account has been created on P1090';
     vm.credentials.temp_name = "customer-registration-en";
     vm.credentials.userStatus = '1';
      UsersService.userSignup(vm.credentials)
        .then(onUserSignupSuccess)
        .catch(onUserSignupError);
    }
    function signin(isValid) {
      if (!isValid) {
        $scope.$broadcast('show-errors-check-validity', 'vm.userForm');
        return false;
      }
      vm.credentials.userType = 'user';
      UsersService.userSignin(vm.credentials)
        .then(onUserSigninSuccess)
        .catch(onUserSigninError);
    }
    function adminsignin(isValid) {
      if (!isValid) {
        $scope.$broadcast('show-errors-check-validity', '$scope.userForm');
        return false;
      }
      vm.credentials.userType = 'admin';
      UsersService.userSignin(vm.credentials)
        .then(onAdminSigninSuccess)
        .catch(onUserSigninError);
    }

    // OAuth provider request
    function callOauthProvider(url) {
      if ($state.previous && $state.previous.href) {
        url += '?redirect_to=' + encodeURIComponent($state.previous.href);
      }

      // Effectively call OAuth authentication route:
      $window.location.href = url;
    }

    // Authentication Callbacks
    function onUserSignupSuccess(response) {
      // If successful we assign the response to the global user model
      vm.authentication.user = response;
      
      Notification.success({ message: '<i class="glyphicon glyphicon-ok"></i> Your registraion has been completed successfully!' });
      // And redirect to the previous or home page
       window.location = '/verification/mobile-number';

        //      $state.go($state.previous.state.name || 'authentication.signin', $state.previous.params);
    
      //$state.go('settings.account-verification');
    }

    function onUserSignupError(response) {
      Notification.error({ message: response.data.message, title: '<i class="glyphicon glyphicon-remove"></i> Signup Error!', delay: 6000 });
    }
    
    
    function onUserSigninSuccess(response) {
        
      if ('user'!== vm.credentials.userType) {
        $http.get('/api/auth/signout').success(function() {
        }).error(function() {
        });
        Notification.error({ message: '<i class="glyphicon glyphicon-remove"></i> Sorry, your username or password is invalid!' });
        if (vm.credentials.userType === 'admin') {
          window.location = '/administrator/login';
          // $state.go('authentication.admin');
        } else {
          $state.go('authentication.signin');
        }
        
      }else if(response.userStatus!=='1')
      {
        $http.get('/api/auth/signout').success(function() {
        }).error(function() {
        });
       if(response.userStatus==='0')
       {
        Notification.error({ message: '<i class="glyphicon glyphicon-remove"></i> Sorry, your account is not activated yet!' });
       }else if(response.userStatus==='2')
       {
        Notification.error({ message: '<i class="glyphicon glyphicon-remove"></i> Sorry, your account is blocked!' });   
       }
        if (vm.credentials.userType === 'admin') {
          window.location = '/administrator/login';
          // $state.go('authentication.admin');
        } else {
          $state.go('authentication.signin');
        }  
      } else {
//        // If successful we assign the response to the global user model
        vm.authentication.user = response;
        Notification.info({ message: 'Welcome ' + response.firstName });
//         // And redirect to the previous or home page
        if (vm.credentials.userType === 'admin') {
//            $state.go('admin.dashboard');
          window.location= '/admin/dashboard';
        } else  if (vm.credentials.userType === 'user') {
            if(response.isMobileVerified==='0')
           {
               window.location = '/verification/mobile-number';
           }else{
            window.location = '/settings/profile';
           }
         // $state.go($state.previous.state.name || 'home', $state.previous.params);
        }else if (vm.credentials.userType === 'technician') {
            if(response.isMobileVerified==='0')
           {
               window.location = '/verification/mobile-number';
           }else{
              window.location = '/settings/profile';
           }
        }else{
             $http.get('/api/auth/signout').success(function() {
                }).error(function() {
                });
          window.location = '/authentication/signin';
        }
      }
//      // If successful we assign the response to the global user model
//      vm.authentication.user = response;
//      Notification.info({ message: 'Welcome ' + response.firstName });
//      // And redirect to the previous or home page
//      $state.go($state.previous.state.name || 'home', $state.previous.params);
    }
    
    function onAdminSigninSuccess(response) {
   
//        // If successful we assign the response to the global user model
        vm.authentication.user = response;
        Notification.info({ message: 'Welcome ' + response.firstName });
//         // And redirect to the previous or home page
        if (vm.authentication.user.userType === 'admin') {
//            $state.go('admin.dashboard');
          window.location= '/admin/dashboard';
        }else if (vm.authentication.user.userType=== 'areamanager') {
          window.location= '/admin/managerdashboard';
        }else if (vm.authentication.user.userType=== 'controller') {
//            $state.go('admin.dashboard');
          window.location= '/admin/controllerdashboard';
        }
        else {
          $state.go($state.previous.state.name || 'home', $state.previous.params);
        }
      
//      // If successful we assign the response to the global user model
//      vm.authentication.user = response;
//      Notification.info({ message: 'Welcome ' + response.firstName });
//      // And redirect to the previous or home page
//      $state.go($state.previous.state.name || 'home', $state.previous.params);
    }
    function onUserSigninError(response) {
      Notification.error({ message: response.data.message, title: '<i class="glyphicon glyphicon-remove"></i> Signin Error!', delay: 6000 });
    }
  }
}());
