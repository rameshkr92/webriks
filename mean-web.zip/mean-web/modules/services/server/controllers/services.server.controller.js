'use strict';

/**
 * Module dependencies
 */
var path = require('path'),
   fs = require('fs'),
  multer = require('multer'),
  config = require(path.resolve('./config/config')),
  mongoose = require('mongoose'),
  Service = mongoose.model('Service'),
  errorHandler = require(path.resolve('./modules/core/server/controllers/errors.server.controller'));

/**
 * Create an service
 */
exports.create = function (req, res) {
  
  var service = new Service(req.body);
  service.user = req.body.user;
  
    service.save(function (err) {
    if (err) {
      return res.status(422).send({
        message: errorHandler.getErrorMessage(err)
      });
    } else {
      res.json(service);
    }
  });
};
exports.changeProfilePicture = function (req, res) {
  var user = req.user;
  //var existingImageUrl;

  // Filtering to upload only images
  var multerConfig = config.uploads.services_images.image;
  multerConfig.fileFilter = require(path.resolve('./config/lib/multer')).imageFileFilter;
  var upload = multer(multerConfig).single('newServicePicture');

  if (user) {
    //existingImageUrl = user.image;
    //user.imagePath=config.uploads.services_images.image.dest + req.file.filename;
    uploadImage()
   
     // .then(updateUser)
    //  .then(deleteOldImage)
      .then(function () {
          var uploadPath=config.uploads.services_images.image.dest+req.file.filename;
        res.json(uploadPath);
      })
      .catch(function (err) {
        res.status(422).send(err);
      });
  } else {
    res.status(401).send({
      message: 'User is not signed in'
    });
  }

  function uploadImage () {
    return new Promise(function (resolve, reject) {
      upload(req, res, function (uploadError) {
        if (uploadError) {
          reject(errorHandler.getErrorMessage(uploadError));
        } else {
          resolve();
        }
      });
    });
  }

};
/**
 * Show the current service
 */
exports.read = function (req, res) {
  // convert mongoose document to JSON
  var service = req.service ? req.service.toJSON() : {};

  // Add a custom field to the Service, for determining if the current User is the "owner".
  // NOTE: This field is NOT persisted to the database, since it doesn't exist in the Service model.
  service.isCurrentUserOwner = !!(req.user && service.user && service.user._id.toString() === req.user._id.toString());

  res.json(service);
};

/**
 * Update an service
 */
exports.update = function (req, res) {
   
  var service = req.service;
  service.title = req.body.title;
  service.display_on_home = req.body.display_on_home;
  service.short_desc= req.body.short_desc;
  if(req.body.parentId === '')
  {
       service.parentId = null;
  }else{
       service.parentId =req.body.parentId ;
  }
  if(req.body.image !== '')
  {
    service.image =req.body.image ;
  }
  if(req.body.service_content !== '')
  {
    service.service_content =req.body.service_content ;
  }
 
  

  service.save(function (err) {
    if (err) {
      return res.status(422).send({
        message: errorHandler.getErrorMessage(err)
      });
    } else {
      res.json(service);
    }
  });
};

/**
 * Delete an service
 */
exports.delete = function (req, res) {
  var service = req.service;

  service.remove(function (err) {
    if (err) {
      return res.status(422).send({
        message: errorHandler.getErrorMessage(err)
      });
    } else {
      res.json(service);
    }
  });
};

/**
 * List of Services
 */
exports.list = function (req, res) {
  Service.find().sort('-created').populate('user', 'displayName').populate('parentId', 'title').exec(function (err, services) {
    if (err) {
      return res.status(422).send({
        message: errorHandler.getErrorMessage(err)
      });
    } else {
      res.json(services);
    }
  });
};

/**
 * Service middleware
 */
exports.serviceByID = function (req, res, next, id) {

  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(400).send({
      message: 'Service is invalid'
    });
  }

  Service.findById(id).populate('user', 'displayName').exec(function (err, service) {
    if (err) {
      return next(err);
    } else if (!service) {
      return res.status(404).send({
        message: 'No service with that identifier has been found'
      });
    }
    req.service = service;
    next();
  });
};
