'use strict';

/**
 * Module dependencies
 */
var mongoose = require('mongoose'),
  Schema = mongoose.Schema;

/**
 * Service Schema
 */
var ServiceSchema = new Schema({
  created: {
    type: Date,
    default: Date.now
  },
 
title:{
        en: {
        type: String,
        default: '',
        required: 'Please fill title',
        trim: true
            },
        ar : {
            type: String,
            default: '',
            trim: true
        }
 },
  
short_desc:{
        en: {
        type: String,
        default: '',
        required: 'Please fill service short description',
        trim: true
            },
        ar : {
            type: String,
            default: '',
            trim: true
        }
 },
service_content:{
        en: {
        type: String,
        default: '',
        required: 'Please fill service detail contents.',
        trim: true
            },
        ar : {
            type: String,
            default: '',
            trim: true
        }
 },
 parentId: {
    type: Schema.ObjectId,
    default: null,
    ref: 'Service'
  },
 image: {
    type: String,
    default: '',
    required: 'Please upload service image.',
  },
 icon_image: {
    type: String,
    default: '',
    required: 'Please upload service icon.',     
  },
  display_on_home: {
    type: String,
    enum:['0','1'],
    default: '0'
  },
  user: {
    type: Schema.ObjectId,
    ref: 'User'
  }
});

mongoose.model('Service', ServiceSchema);
