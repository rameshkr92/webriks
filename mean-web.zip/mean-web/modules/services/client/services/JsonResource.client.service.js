(function () {
  'use strict';

  angular
    .module('services.services')
    .factory('JsonResourceService', JsonResourceService);

  JsonResourceService.$inject = ['$resource', '$log'];
  function JsonResourceService($resource, $log) {
    return $resource('/api/services/', {}, {
      query: {
        method: 'GET',
        transformResponse: function(data) {
          return angular.fromJson(data).events;
        },
        isArray: true
      }
    });
  }
}());
