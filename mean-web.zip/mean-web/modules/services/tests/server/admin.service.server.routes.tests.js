﻿'use strict';

var should = require('should'),
  request = require('supertest'),
  path = require('path'),
  mongoose = require('mongoose'),
  User = mongoose.model('User'),
  Service = mongoose.model('Service'),
  express = require(path.resolve('./config/lib/express'));

/**
 * Globals
 */
var app,
  agent,
  credentials,
  user,
  service;

/**
 * Service routes tests
 */
describe('Service Admin CRUD tests', function () {
  before(function (done) {
    // Get application
    app = express.init(mongoose);
    agent = request.agent(app);

    done();
  });

  beforeEach(function (done) {
    // Create user credentials
    credentials = {
      usernameOrEmail: 'username',
      password: 'M3@n.jsI$Aw3$0m3'
    };

    // Create a new user
    user = new User({
      firstName: 'Full',
      lastName: 'Name',
      displayName: 'Full Name',
      email: 'test@test.com',
      roles: ['user', 'admin'],
      username: credentials.usernameOrEmail,
      password: credentials.password,
      provider: 'local'
    });

    // Save a user to the test db and create new service
    user.save(function () {
      service = {
        title: 'Service Title',
        content: 'Service Content'
      };

      done();
    });
  });

  it('should be able to save an service if logged in', function (done) {
    agent.post('/api/auth/signin')
      .send(credentials)
      .expect(200)
      .end(function (signinErr, signinRes) {
        // Handle signin error
        if (signinErr) {
          return done(signinErr);
        }

        // Get the userId
        var userId = user.id;

        // Save a new service
        agent.post('/api/services')
          .send(service)
          .expect(200)
          .end(function (serviceSaveErr, serviceSaveRes) {
            // Handle service save error
            if (serviceSaveErr) {
              return done(serviceSaveErr);
            }

            // Get a list of services
            agent.get('/api/services')
              .end(function (servicesGetErr, servicesGetRes) {
                // Handle service save error
                if (servicesGetErr) {
                  return done(servicesGetErr);
                }

                // Get services list
                var services = servicesGetRes.body;

                // Set assertions
                (services[0].user._id).should.equal(userId);
                (services[0].title).should.match('Service Title');

                // Call the assertion callback
                done();
              });
          });
      });
  });

  it('should be able to update an service if signed in', function (done) {
    agent.post('/api/auth/signin')
      .send(credentials)
      .expect(200)
      .end(function (signinErr, signinRes) {
        // Handle signin error
        if (signinErr) {
          return done(signinErr);
        }

        // Get the userId
        var userId = user.id;

        // Save a new service
        agent.post('/api/services')
          .send(service)
          .expect(200)
          .end(function (serviceSaveErr, serviceSaveRes) {
            // Handle service save error
            if (serviceSaveErr) {
              return done(serviceSaveErr);
            }

            // Update service title
            service.title = 'WHY YOU GOTTA BE SO MEAN?';

            // Update an existing service
            agent.put('/api/services/' + serviceSaveRes.body._id)
              .send(service)
              .expect(200)
              .end(function (serviceUpdateErr, serviceUpdateRes) {
                // Handle service update error
                if (serviceUpdateErr) {
                  return done(serviceUpdateErr);
                }

                // Set assertions
                (serviceUpdateRes.body._id).should.equal(serviceSaveRes.body._id);
                (serviceUpdateRes.body.title).should.match('WHY YOU GOTTA BE SO MEAN?');

                // Call the assertion callback
                done();
              });
          });
      });
  });

  it('should not be able to save an service if no title is provided', function (done) {
    // Invalidate title field
    service.title = '';

    agent.post('/api/auth/signin')
      .send(credentials)
      .expect(200)
      .end(function (signinErr, signinRes) {
        // Handle signin error
        if (signinErr) {
          return done(signinErr);
        }

        // Get the userId
        var userId = user.id;

        // Save a new service
        agent.post('/api/services')
          .send(service)
          .expect(422)
          .end(function (serviceSaveErr, serviceSaveRes) {
            // Set message assertion
            (serviceSaveRes.body.message).should.match('Title cannot be blank');

            // Handle service save error
            done(serviceSaveErr);
          });
      });
  });

  it('should be able to delete an service if signed in', function (done) {
    agent.post('/api/auth/signin')
      .send(credentials)
      .expect(200)
      .end(function (signinErr, signinRes) {
        // Handle signin error
        if (signinErr) {
          return done(signinErr);
        }

        // Get the userId
        var userId = user.id;

        // Save a new service
        agent.post('/api/services')
          .send(service)
          .expect(200)
          .end(function (serviceSaveErr, serviceSaveRes) {
            // Handle service save error
            if (serviceSaveErr) {
              return done(serviceSaveErr);
            }

            // Delete an existing service
            agent.delete('/api/services/' + serviceSaveRes.body._id)
              .send(service)
              .expect(200)
              .end(function (serviceDeleteErr, serviceDeleteRes) {
                // Handle service error error
                if (serviceDeleteErr) {
                  return done(serviceDeleteErr);
                }

                // Set assertions
                (serviceDeleteRes.body._id).should.equal(serviceSaveRes.body._id);

                // Call the assertion callback
                done();
              });
          });
      });
  });

  it('should be able to get a single service if signed in and verify the custom "isCurrentUserOwner" field is set to "true"', function (done) {
    // Create new service model instance
    service.user = user;
    var serviceObj = new Service(service);

    agent.post('/api/auth/signin')
      .send(credentials)
      .expect(200)
      .end(function (signinErr, signinRes) {
        // Handle signin error
        if (signinErr) {
          return done(signinErr);
        }

        // Get the userId
        var userId = user.id;

        // Save a new service
        agent.post('/api/services')
          .send(service)
          .expect(200)
          .end(function (serviceSaveErr, serviceSaveRes) {
            // Handle service save error
            if (serviceSaveErr) {
              return done(serviceSaveErr);
            }

            // Get the service
            agent.get('/api/services/' + serviceSaveRes.body._id)
              .expect(200)
              .end(function (serviceInfoErr, serviceInfoRes) {
                // Handle service error
                if (serviceInfoErr) {
                  return done(serviceInfoErr);
                }

                // Set assertions
                (serviceInfoRes.body._id).should.equal(serviceSaveRes.body._id);
                (serviceInfoRes.body.title).should.equal(service.title);

                // Assert that the "isCurrentUserOwner" field is set to true since the current User created it
                (serviceInfoRes.body.isCurrentUserOwner).should.equal(true);

                // Call the assertion callback
                done();
              });
          });
      });
  });

  afterEach(function (done) {
    User.remove().exec(function () {
      Service.remove().exec(done);
    });
  });
});
