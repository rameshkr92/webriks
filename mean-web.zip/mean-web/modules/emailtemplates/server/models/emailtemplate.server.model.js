'use strict';

/**
 * Module dependencies
 */
var mongoose = require('mongoose'),
  Schema = mongoose.Schema;

/**
 * Emailtemplate Schema
 */
var EmailtemplateSchema = new Schema({
  created: {
    type: Date,
    default: Date.now
  },
  emailurl: {
    type: String,
    default: '',
    required: 'Please fill email template url',
    trim: true
  },
   title:{
        en: {
        type: String,
        default: '',
        required: 'Please fill cms title',
        trim: true
            },
        ar : {
            type: String,
            default: '',
            trim: true
        }
 },
  content:{
        en: {
        type: String,
        default: '',
        required: 'Please fill cms title',
        trim: true
            },
        ar : {
            type: String,
            default: '',
            trim: true
        }
 },
  
  user: {
    type: Schema.ObjectId,
    ref: 'User'
  }
});

mongoose.model('Emailtemplate', EmailtemplateSchema);
