﻿'use strict';

var should = require('should'),
  request = require('supertest'),
  path = require('path'),
  mongoose = require('mongoose'),
  User = mongoose.model('User'),
  Emailtemplate = mongoose.model('Emailtemplate'),
  express = require(path.resolve('./config/lib/express'));

/**
 * Globals
 */
var app,
  agent,
  credentials,
  user,
  emailtemplate;

/**
 * Emailtemplate routes tests
 */
describe('Emailtemplate Admin CRUD tests', function () {
  before(function (done) {
    // Get application
    app = express.init(mongoose);
    agent = request.agent(app);

    done();
  });

  beforeEach(function (done) {
    // Create user credentials
    credentials = {
      usernameOrEmail: 'username',
      password: 'M3@n.jsI$Aw3$0m3'
    };

    // Create a new user
    user = new User({
      firstName: 'Full',
      lastName: 'Name',
      displayName: 'Full Name',
      email: 'test@test.com',
      roles: ['user', 'admin'],
      username: credentials.usernameOrEmail,
      password: credentials.password,
      provider: 'local'
    });

    // Save a user to the test db and create new emailtemplate
    user.save(function () {
      emailtemplate = {
        title: 'Emailtemplate Title',
        content: 'Emailtemplate Content'
      };

      done();
    });
  });

  it('should be able to save an emailtemplate if logged in', function (done) {
    agent.post('/api/auth/signin')
      .send(credentials)
      .expect(200)
      .end(function (signinErr, signinRes) {
        // Handle signin error
        if (signinErr) {
          return done(signinErr);
        }

        // Get the userId
        var userId = user.id;

        // Save a new emailtemplate
        agent.post('/api/emailtemplates')
          .send(emailtemplate)
          .expect(200)
          .end(function (emailtemplateSaveErr, emailtemplateSaveRes) {
            // Handle emailtemplate save error
            if (emailtemplateSaveErr) {
              return done(emailtemplateSaveErr);
            }

            // Get a list of emailtemplates
            agent.get('/api/emailtemplates')
              .end(function (emailtemplatesGetErr, emailtemplatesGetRes) {
                // Handle emailtemplate save error
                if (emailtemplatesGetErr) {
                  return done(emailtemplatesGetErr);
                }

                // Get emailtemplates list
                var emailtemplates = emailtemplatesGetRes.body;

                // Set assertions
                (emailtemplates[0].user._id).should.equal(userId);
                (emailtemplates[0].title).should.match('Emailtemplate Title');

                // Call the assertion callback
                done();
              });
          });
      });
  });

  it('should be able to update an emailtemplate if signed in', function (done) {
    agent.post('/api/auth/signin')
      .send(credentials)
      .expect(200)
      .end(function (signinErr, signinRes) {
        // Handle signin error
        if (signinErr) {
          return done(signinErr);
        }

        // Get the userId
        var userId = user.id;

        // Save a new emailtemplate
        agent.post('/api/emailtemplates')
          .send(emailtemplate)
          .expect(200)
          .end(function (emailtemplateSaveErr, emailtemplateSaveRes) {
            // Handle emailtemplate save error
            if (emailtemplateSaveErr) {
              return done(emailtemplateSaveErr);
            }

            // Update emailtemplate title
            emailtemplate.title = 'WHY YOU GOTTA BE SO MEAN?';

            // Update an existing emailtemplate
            agent.put('/api/emailtemplates/' + emailtemplateSaveRes.body._id)
              .send(emailtemplate)
              .expect(200)
              .end(function (emailtemplateUpdateErr, emailtemplateUpdateRes) {
                // Handle emailtemplate update error
                if (emailtemplateUpdateErr) {
                  return done(emailtemplateUpdateErr);
                }

                // Set assertions
                (emailtemplateUpdateRes.body._id).should.equal(emailtemplateSaveRes.body._id);
                (emailtemplateUpdateRes.body.title).should.match('WHY YOU GOTTA BE SO MEAN?');

                // Call the assertion callback
                done();
              });
          });
      });
  });

  it('should not be able to save an emailtemplate if no title is provided', function (done) {
    // Invalidate title field
    emailtemplate.title = '';

    agent.post('/api/auth/signin')
      .send(credentials)
      .expect(200)
      .end(function (signinErr, signinRes) {
        // Handle signin error
        if (signinErr) {
          return done(signinErr);
        }

        // Get the userId
        var userId = user.id;

        // Save a new emailtemplate
        agent.post('/api/emailtemplates')
          .send(emailtemplate)
          .expect(422)
          .end(function (emailtemplateSaveErr, emailtemplateSaveRes) {
            // Set message assertion
            (emailtemplateSaveRes.body.message).should.match('Title cannot be blank');

            // Handle emailtemplate save error
            done(emailtemplateSaveErr);
          });
      });
  });

  it('should be able to delete an emailtemplate if signed in', function (done) {
    agent.post('/api/auth/signin')
      .send(credentials)
      .expect(200)
      .end(function (signinErr, signinRes) {
        // Handle signin error
        if (signinErr) {
          return done(signinErr);
        }

        // Get the userId
        var userId = user.id;

        // Save a new emailtemplate
        agent.post('/api/emailtemplates')
          .send(emailtemplate)
          .expect(200)
          .end(function (emailtemplateSaveErr, emailtemplateSaveRes) {
            // Handle emailtemplate save error
            if (emailtemplateSaveErr) {
              return done(emailtemplateSaveErr);
            }

            // Delete an existing emailtemplate
            agent.delete('/api/emailtemplates/' + emailtemplateSaveRes.body._id)
              .send(emailtemplate)
              .expect(200)
              .end(function (emailtemplateDeleteErr, emailtemplateDeleteRes) {
                // Handle emailtemplate error error
                if (emailtemplateDeleteErr) {
                  return done(emailtemplateDeleteErr);
                }

                // Set assertions
                (emailtemplateDeleteRes.body._id).should.equal(emailtemplateSaveRes.body._id);

                // Call the assertion callback
                done();
              });
          });
      });
  });

  it('should be able to get a single emailtemplate if signed in and verify the custom "isCurrentUserOwner" field is set to "true"', function (done) {
    // Create new emailtemplate model instance
    emailtemplate.user = user;
    var emailtemplateObj = new Emailtemplate(emailtemplate);

    agent.post('/api/auth/signin')
      .send(credentials)
      .expect(200)
      .end(function (signinErr, signinRes) {
        // Handle signin error
        if (signinErr) {
          return done(signinErr);
        }

        // Get the userId
        var userId = user.id;

        // Save a new emailtemplate
        agent.post('/api/emailtemplates')
          .send(emailtemplate)
          .expect(200)
          .end(function (emailtemplateSaveErr, emailtemplateSaveRes) {
            // Handle emailtemplate save error
            if (emailtemplateSaveErr) {
              return done(emailtemplateSaveErr);
            }

            // Get the emailtemplate
            agent.get('/api/emailtemplates/' + emailtemplateSaveRes.body._id)
              .expect(200)
              .end(function (emailtemplateInfoErr, emailtemplateInfoRes) {
                // Handle emailtemplate error
                if (emailtemplateInfoErr) {
                  return done(emailtemplateInfoErr);
                }

                // Set assertions
                (emailtemplateInfoRes.body._id).should.equal(emailtemplateSaveRes.body._id);
                (emailtemplateInfoRes.body.title).should.equal(emailtemplate.title);

                // Assert that the "isCurrentUserOwner" field is set to true since the current User created it
                (emailtemplateInfoRes.body.isCurrentUserOwner).should.equal(true);

                // Call the assertion callback
                done();
              });
          });
      });
  });

  afterEach(function (done) {
    User.remove().exec(function () {
      Emailtemplate.remove().exec(done);
    });
  });
});
