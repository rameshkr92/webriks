(function () {
  'use strict';

  angular
    .module('emailtemplates.routes')
    .config(routeConfig);

  routeConfig.$inject = ['$stateProvider'];

  function routeConfig($stateProvider) {
    $stateProvider
      .state('emailtemplates', {
        abstract: true,
        url: '/emailtemplates',
        template: '<ui-view/>'
      })
      .state('emailtemplates.list', {
        url: '',
        templateUrl: '/modules/emailtemplates/client/views/list-emailtemplates.client.view.html',
        controller: 'EmailtemplatesListController',
        controllerAs: 'vm',
        data: {
          pageTitle: 'Emailtemplates List'
        }
      })
      .state('emailtemplates.view', {
        url: '/:emailtemplateId',
        templateUrl: '/modules/emailtemplates/client/views/view-emailtemplate.client.view.html',
        controller: 'EmailtemplatesController',
        controllerAs: 'vm',
        resolve: {
          emailtemplateResolve: getEmailtemplate
        },
        data: {
          pageTitle: 'Emailtemplate {{ emailtemplateResolve.title }}'
        }
      });
  }

  getEmailtemplate.$inject = ['$stateParams', 'EmailtemplatesService'];

  function getEmailtemplate($stateParams, EmailtemplatesService) {
    return EmailtemplatesService.get({
      emailtemplateId: $stateParams.emailtemplateId
    }).$promise;
  }
}());
