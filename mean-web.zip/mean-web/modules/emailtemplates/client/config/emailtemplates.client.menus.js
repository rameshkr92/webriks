(function () {
  'use strict';

  angular
    .module('emailtemplates')
    .run(menuConfig);

  menuConfig.$inject = ['menuService'];

  function menuConfig(menuService) {
    menuService.addMenuItem('topbar', {
      title: 'Emailtemplates',
      state: 'emailtemplates',
      type: 'dropdown',
      roles: ['*']
    });

    // Add the dropdown list item
    menuService.addSubMenuItem('topbar', 'emailtemplates', {
      title: 'List Emailtemplates',
      state: 'emailtemplates.list',
      roles: ['*']
    });
  }
}());
