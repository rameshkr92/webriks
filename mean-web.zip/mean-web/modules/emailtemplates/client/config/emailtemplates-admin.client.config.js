﻿(function () {
  'use strict';

  // Configuring the Emailtemplates Admin module
  angular
    .module('emailtemplates.admin')
    .run(menuConfig);

  menuConfig.$inject = ['menuService'];

  function menuConfig(Menus) {
    Menus.addSubMenuItem('topbar', 'admin', {
      title: 'Manage Emailtemplates',
      state: 'admin.emailtemplates.list'
    });
  }
}());
