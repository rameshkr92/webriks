(function () {
  'use strict';

  angular
    .module('emailtemplates.services')
    .factory('JsonResourceService', JsonResourceService);

  JsonResourceService.$inject = ['$resource', '$log'];

  function JsonResourceService($resource, $log) {
    return $resource('/api/emailtemplates/', {}, {
      query: {
        method: 'GET',
        transformResponse: function(data) {
          return angular.fromJson(data).events;
        },
        isArray: true
      }
   });
   
  }
}());
