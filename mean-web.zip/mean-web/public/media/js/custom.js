$(document).ready(function(){

	applyOrientation();
        
          if ($('html').hasClass('desktop')) {
        new WOW().init();
      }
     setTimeout(function(){
        $('#service-slide').owlCarousel({
		loop:true,
		margin:1,
		nav:true,
		autoplay:true,
		dots:false,
		navText: [
            "<i class='fa fa-angle-left'></i>",
            "<i class='fa fa-angle-right'></i>"
        ],
		responsive:{
			0:{
				items:1
			},
			600:{
				items:2
			},
			800:{
				items:3
			},
			1000:{
				items:4
			},
			1200:{
				items:5
			}
		}
	});
    },500);
 
	
	$('.search-header').click(function () {
		$('body').toggleClass('search-drop')
		$(this).toggleClass('search-close')
	});
	
	$('.nav-open-btn').click(function () {
		$('body').toggleClass('log-dash-open')
		$(this).toggleClass('cross-icon')
	});
	
	$('.msg-click').click(function () {
		$('body').toggleClass('msg-click-open')
	});
	
	$('.msg-right-pannel .media').click(function(){
		$('body').addClass('sub-detail-open');
	});
	$('.msg-closer').click(function(){
		$('body').removeClass('sub-detail-open');
	});
	
	$('.footer-navs li a').hover(function () {
		$('body').toggleClass('nav-effect')
		$(this).toggleClass('nav-effect-color')
	});
	
$(function () { 
  $('[data-toggle="tooltip"]').tooltip({trigger: 'manual'}).tooltip('show');
});  

function moved() {
	alert('in');
	var owl = $(".owl-carousel").data('owlCarousel');
	if (owl.currentItem + 1 === owl.itemsAmount) {
		alert('THE END');
	}
}
	


$.scrollIt({
		upKey: 40,             // key code to navigate to the next section
		downKey: 40,           // key code to navigate to the previous section
		easing: 'ease-in-out',      // the easing function for animation
		scrollTime: 1500,       // how long (in ms) the animation takes
		activeClass: 'active', // class given to the active nav element
		onPageChange: null,    // function(pageIndex) that is called when page is changed
		topOffset:0           // offste (in px) for fixed top navigation
	});
       setTimeout(function(){ 
        $('#banner-slide').owlCarousel({
		loop:true,
		margin:1,
		nav:false,
		animateOut: 'fadeOut',
		animateIn: 'fadeIn',
		dots:false,
		autoplay:true,
		items:1
		
	});
        fullSize();
    },400);
     $('body').append('<div id="toTop" class="btn"><span class="fa fa-angle-up"></span></div>');
    	$(window).scroll(function () {
			if ($(this).scrollTop() != 0) {
				$('#toTop').fadeIn();
			} else {
				$('#toTop').fadeOut();
			}
		}); 
    $('#toTop').click(function(){
        $("html, body").animate({ scrollTop: 0 }, 1500);
        return false;
    });    
    $('[data-toggle="tooltip"]').tooltip();
    $('a[title]').tooltip();
    	
});

$(window).on('load',function(){
	if (window.innerWidth > 1024 ) {
		var s = skrollr.init();
	}
});

$( window ).resize(function() {
	fullSize();
});
$(window).bind("load", function() {
//    var footer = $("footer");
//                 var pos = footer.position();
//                 var height = $(window).height();
//                 height = height - pos.top;
//                 height = height - footer.height();
//                 if (height > 0) {
//                 footer.css({'margin-top' : height+'px'});
//    }
});



function fullSize() {
    var heights = window.innerHeight;
    $(".banner-slider .item").css('min-height', (heights + 0) + "px");
}

function applyOrientation() {
    if (window.innerHeight > window.innerWidth) {
        $("body").addClass("potrait");
        $("body").removeClass("landscape");
    } else {
        $("body").addClass("landscape");
        $("body").removeClass("potrait");
    }
}

var banner_Ht = window.innerHeight - $('header').innerHeight();	
	$(window).scroll(function(){
	  var sticky = $('body'),
		  scroll = $(window).scrollTop();
	
	  if (scroll >= 100) sticky.addClass('sticky-header');
	  else sticky.removeClass('sticky-header');
});


$('.accordion').on('shown.bs.collapse', function (e) {
	$(e.target).parent().addClass('active_acc');
	$(e.target).prev().find('.switch').removeClass('fa-plus');
	$(e.target).prev().find('.switch').addClass('fa-minus');
});
$('.accordion').on('hidden.bs.collapse', function (e) {
	$(e.target).parent().removeClass('active_acc');
	$(e.target).prev().find('.switch').addClass('fa-plus');
	$(e.target).prev().find('.switch').removeClass('fa-minus');
}); 


wrapper   = $(".tabs");
tabs      = wrapper.find(".tab");
tabToggle = wrapper.find(".tab-toggle");

// ----------------- Functions

function openTab() {
	var content     = $(this).parent().next(".content"),
		activeItems = wrapper.find(".active");
	
	if(!$(this).hasClass('active')) {
		$(this).add(content).add(activeItems).toggleClass('active');
		wrapper.css('min-height', content.outerHeight());
	}
};

// ----------------- Interactions

tabToggle.on('click', openTab);

// ----------------- Constructor functions

$(window).on('load',function(){
  tabToggle.first().trigger('click');  
  
});
