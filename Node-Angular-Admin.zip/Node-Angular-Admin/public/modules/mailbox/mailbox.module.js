'use strict';

ApplicationConfiguration.registerModule('app.mailbox');