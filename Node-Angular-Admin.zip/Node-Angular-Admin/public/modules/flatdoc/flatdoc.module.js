'use strict';

ApplicationConfiguration.registerModule('app.flatdoc');