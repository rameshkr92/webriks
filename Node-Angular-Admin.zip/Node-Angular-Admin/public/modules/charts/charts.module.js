'use strict';

ApplicationConfiguration.registerModule('app.charts', ['app.routes']);