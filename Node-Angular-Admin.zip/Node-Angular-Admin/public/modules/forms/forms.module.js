'use strict';

ApplicationConfiguration.registerModule('app.forms');