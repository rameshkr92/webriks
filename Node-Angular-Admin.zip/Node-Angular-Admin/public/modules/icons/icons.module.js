'use strict';

ApplicationConfiguration.registerModule('app.icons');