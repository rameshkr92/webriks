(function() {
    'use strict';

    ApplicationConfiguration.registerModule('app.settings');

})();