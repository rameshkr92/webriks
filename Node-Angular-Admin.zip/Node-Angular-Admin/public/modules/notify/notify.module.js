'use strict';

ApplicationConfiguration.registerModule('app.notify');