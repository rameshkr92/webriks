'use strict';

ApplicationConfiguration.registerModule('app.bootstrapui');
