(function() {
    'use strict';

    ApplicationConfiguration.registerModule('app.navsearch');
})();