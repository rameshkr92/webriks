'use strict';

ApplicationConfiguration.registerModule('app.dashboard');
