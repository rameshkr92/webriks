(function() {
    'use strict';

    ApplicationConfiguration.registerModule('app.preloader');

})();

