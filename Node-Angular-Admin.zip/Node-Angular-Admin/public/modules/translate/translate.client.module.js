(function() {
    'use strict';

    ApplicationConfiguration.registerModule('app.translate');

})();