'use strict';

ApplicationConfiguration.registerModule('app.blog', ['app.routes']);
